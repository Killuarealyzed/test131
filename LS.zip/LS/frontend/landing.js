// ===== ГЕНЕРАЦИЯ СНЕГА =====
function createSnow() {
    const snowContainer = document.getElementById('snow');
    if (!snowContainer) return;
    
    const flakeCount = 50; // Оптимальное количество
    
    for (let i = 0; i < flakeCount; i++) {
        const flake = document.createElement('div');
        flake.className = 'snowflake';
        
        // Случайный размер (2-5px)
        const size = Math.random() * 3 + 2;
        flake.style.width = size + 'px';
        flake.style.height = size + 'px';
        
        // Случайная позиция по X
        flake.style.left = Math.random() * 100 + '%';
        
        // Случайная длительность (8-15 сек)
        const duration = Math.random() * 7 + 8;
        flake.style.animationDuration = duration + 's';
        
        // Случайная задержка
        flake.style.animationDelay = Math.random() * 10 + 's';
        
        // Случайная прозрачность
        flake.style.opacity = Math.random() * 0.5 + 0.3;
        
        snowContainer.appendChild(flake);
    }
}

createSnow();

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// ===== HEADER SHADOW =====
const header = document.querySelector('.header');
window.addEventListener('scroll', () => {
    if (window.pageYOffset > 50) {
        header.style.boxShadow = '0 2px 20px rgba(0,0,0,0.3)';
    } else {
        header.style.boxShadow = 'none';
    }
}, { passive: true });