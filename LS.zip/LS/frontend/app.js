// Auth
function saveAuth(key) { localStorage.setItem('auth_key', key); }
function getAuth() { return localStorage.getItem('auth_key'); }
function clearAuth() { localStorage.removeItem('auth_key'); }

// Theme
function getTheme() { return localStorage.getItem('theme') || 'light'; }
function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}
function toggleTheme() { setTheme(getTheme() === 'light' ? 'dark' : 'light'); }

// Notification
function notify(message, type) {
    const n = document.createElement('div');
    n.className = 'notification ' + type;
    n.textContent = message;
    document.body.appendChild(n);
    setTimeout(() => n.remove(), 3000);
}

// Data
const subjects = [
    { name: 'Математика', paragraphs: ['Введение', 'Основы', 'Практика'] },
    { name: 'Физика', paragraphs: ['Механика', 'Термодинамика', 'Электричество'] },
    { name: 'Информатика', paragraphs: ['Программирование', 'Алгоритмы', 'Базы данных'] },
    { name: 'История', paragraphs: ['Древний мир', 'Средневековье', 'Новое время'] },
    { name: 'Химия', paragraphs: ['Атом', 'Связи', 'Органика'] }
];

// Init
document.addEventListener('DOMContentLoaded', () => {
    setTheme(getTheme());
    const path = window.location.pathname;
    const savedKey = getAuth();
    
    if (savedKey && (path === '/' || path === '/app')) {
        fetch('/api/activate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key: savedKey, device_id: 'browser-session' })
        }).then(r => r.json()).then(result => {
            if (result.success) window.location.href = '/main';
            else initLogin();
        }).catch(() => initLogin());
    } else if (path === '/' || path === '/app') {
        initLogin();
    } else if (path === '/main') {
        initMain();
    }
});

function initLogin() {
    const form = document.getElementById('loginForm');
    const input = document.getElementById('keyInput');
    const btn = document.getElementById('loginBtn');
    const themeBtn = document.getElementById('themeToggleLogin');
    
    if (themeBtn) themeBtn.addEventListener('click', toggleTheme);
    
    if (input) {
        input.addEventListener('input', (e) => {
            let v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
            if (v && !v.startsWith('LS')) v = 'LS' + v;
            let f = v;
            if (v.length > 2) {
                f = v.substring(0, 2);
                for (let i = 2; i < v.length && i < 14; i++) {
                    if ((i - 2) % 4 === 0) f += '-';
                    f += v[i];
                }
            }
            e.target.value = f;
        });
    }
    
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const key = input.value.trim();
            if (!key) { notify('Введите ключ', 'error'); return; }
            
            btn.querySelector('.btn-text').style.display = 'none';
            btn.disabled = true;
            
            fetch('/api/activate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key, device_id: 'browser-session' })
            }).then(r => r.json()).then(result => {
                if (result.success) {
                    saveAuth(key);
                    notify(result.message, 'success');
                    setTimeout(() => window.location.href = '/main', 800);
                } else {
                    notify(result.message, 'error');
                    btn.querySelector('.btn-text').style.display = 'inline';
                    btn.disabled = false;
                }
            }).catch(() => {
                notify('Ошибка', 'error');
                btn.querySelector('.btn-text').style.display = 'inline';
                btn.disabled = false;
            });
        });
    }
}

function initMain() {
    const savedKey = getAuth();
    if (!savedKey) { 
        window.location.href = '/app'; 
        return; 
    }
    
    // Проверка сессии
    fetch('/api/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: savedKey, device_id: 'browser-session' })
    }).then(r => r.json()).then(result => {
        if (!result.success) { 
            clearAuth(); 
            window.location.href = '/app'; 
        }
    });
    
    // Загрузка профиля
    loadProfile(savedKey);
    
    // Theme toggle
    const themeBtn = document.getElementById('themeToggle');
    if (themeBtn) themeBtn.addEventListener('click', toggleTheme);
    
    // Profile dropdown
    const profileBtn = document.getElementById('profileBtn');
    const dropdown = document.getElementById('profileDropdown');
    if (profileBtn && dropdown) {
        profileBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.toggle('open');
        });
        document.addEventListener('click', (e) => {
            if (!dropdown.contains(e.target) && !profileBtn.contains(e.target)) {
                dropdown.classList.remove('open');
            }
        });
    }
    
    // Logout
    const logoutBtn = document.getElementById('logoutBtnFull');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            clearAuth();
            window.location.href = '/app';
        });
    }
    
    // Рендер предметов
    const list = document.getElementById('subjectsList');
    if (list) {
        subjects.forEach((subj, idx) => {
            const el = document.createElement('div');
            el.className = 'subject';
            
            const paragraphsHTML = subj.paragraphs.map((p, i) => {
                return `<div class="paragraph" data-index="${i}">
                    <span class="paragraph-number">${i + 1}</span>
                    <span class="paragraph-title">${p}</span>
                </div>`;
            }).join('');
            
            el.innerHTML = `
                <div class="subject-header">
                    <span class="subject-name">${subj.name}</span>
                    <svg class="subject-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 18l6-6-6-6"/>
                    </svg>
                </div>
                <div class="paragraphs">
                    ${paragraphsHTML}
                </div>
            `;
            
            const header = el.querySelector('.subject-header');
            header.addEventListener('click', () => {
                const expanded = el.classList.contains('expanded');
                document.querySelectorAll('.subject').forEach(s => {
                    s.classList.remove('expanded');
                    s.querySelector('.subject-header').classList.remove('active');
                });
                if (!expanded) {
                    el.classList.add('expanded');
                    header.classList.add('active');
                }
            });
            
            // Обработчики параграфов
            const paragraphs = el.querySelectorAll('.paragraph');
            paragraphs.forEach((p, i) => {
                p.addEventListener('click', () => {
                    document.querySelectorAll('.paragraph').forEach(x => x.classList.remove('active'));
                    p.classList.add('active');
                    showContent(subj.name, p.querySelector('.paragraph-title').textContent, i + 1);
                });
            });
            
            list.appendChild(el);
        });
    }
}

function loadProfile(key) {
    fetch('/api/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key })
    }).then(r => r.json()).then(data => {
        if (!data.success) return;
        
        const el = (id) => document.getElementById(id);
        if (el('profilePlan')) el('profilePlan').textContent = data.plan;
        if (el('profileKey')) el('profileKey').textContent = data.key;
        if (el('profileExpires')) el('profileExpires').textContent = data.expires_at || '—';
        if (el('profileDevices')) el('profileDevices').textContent = data.used_devices + ' / ' + data.max_devices;
        if (el('profileDevicesFill')) {
            const pct = data.max_devices > 0 ? (data.used_devices / data.max_devices) * 100 : 0;
            el('profileDevicesFill').style.width = pct + '%';
        }
        if (el('profileAvailable')) {
            if (data.available_devices > 0) {
                el('profileAvailable').textContent = 'Доступно ещё ' + data.available_devices + ' мест';
                el('profileAvailable').style.color = 'var(--success)';
            } else {
                el('profileAvailable').textContent = 'Все устройства заняты';
                el('profileAvailable').style.color = 'var(--danger)';
            }
        }
    });
}

function showContent(subj, para, num) {
    const content = document.getElementById('contentArea');
    content.innerHTML = '<div class="paragraph-content"><div class="content-header"><div class="content-breadcrumb">' + subj + '</div><div class="content-number">§ ' + num + '</div><h1 class="content-title">' + para + '</h1></div><div class="content-body"><div class="content-placeholder"><div class="content-placeholder-icon">§</div><p>Материал будет добавлен</p></div></div></div>';
}