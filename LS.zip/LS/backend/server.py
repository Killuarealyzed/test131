from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from database import init_db, check_and_activate, get_profile
import os

app = Flask(__name__)
CORS(app)

FRONTEND = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'frontend')
init_db()

@app.route('/')
def index():
    return send_from_directory(FRONTEND, 'landing.html')

@app.route('/app')
@app.route('/school')
def app_route():
    return send_from_directory(FRONTEND, 'index.html')

@app.route('/main')
def main():
    return send_from_directory(FRONTEND, 'main.html')

@app.route('/services')
@app.route('/company')
def services():
    return send_from_directory(FRONTEND, 'company.html')

@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory(FRONTEND, filename)

@app.route('/api/activate', methods=['POST'])
def activate():
    data = request.get_json()
    key = data.get('key', '')
    device_id = data.get('device_id', 'browser-session')
    if not key:
        return jsonify({"success": False, "message": "Введите ключ"})
    return jsonify(check_and_activate(key, device_id))

@app.route('/api/profile', methods=['POST'])
def profile():
    data = request.get_json()
    key = data.get('key', '')
    if not key:
        return jsonify({"success": False, "message": "Не авторизован"})
    return jsonify(get_profile(key))

if __name__ == '__main__':
    print("=" * 60)
    print("  L1rtus запущен!")
    print("  Лендинг: http://localhost:5000/")
    print("  School: http://localhost:5000/app")
    print("  Company: http://localhost:5000/services")
    print("=" * 60)
    app.run(debug=False, port=5000, threaded=True)