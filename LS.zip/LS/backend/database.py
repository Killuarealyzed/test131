import json
import pandas as pd
import os
import random
from datetime import datetime, timedelta

KEYS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys.json")
REPORT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys_report.xlsx")

KEY_CHARS = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"

PLANS = {
    "starter": {"name": "Starter", "max_devices": 1, "price_month": 990, "price_year": 7990},
    "duo": {"name": "Duo", "max_devices": 2, "price_month": 1790, "price_year": 14990},
    "family": {"name": "Family", "max_devices": 3, "price_month": 2490, "price_year": 19990},
}

def generate_key(plan="starter"):
    groups = []
    for _ in range(3):
        group = "".join(random.choice(KEY_CHARS) for _ in range(4))
        groups.append(group)
    return f"LS-{'-'.join(groups)}"

def init_db():
    if not os.path.exists(KEYS_FILE):
        keys_data = {"keys": []}
        for plan in PLANS:
            keys_data["keys"].append({
                "key": generate_key(plan),
                "plan": plan,
                "status": "inactive",
                "max_devices": PLANS[plan]["max_devices"],
                "active_devices": [],
                "created_at": datetime.now().strftime("%d.%m.%Y"),
                "activated_at": "",
                "expires_at": "",
                "last_login": ""
            })
        with open(KEYS_FILE, 'w', encoding='utf-8') as f:
            json.dump(keys_data, f, ensure_ascii=False, indent=2)
        print("[DB] Созданы тестовые ключи:")
        for k in keys_data["keys"]:
            print(f"  {k['plan'].upper()}: {k['key']}")
    update_excel_report()

def load_keys():
    try:
        with open(KEYS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f).get("keys", [])
    except:
        return []

def save_keys(data):
    with open(KEYS_FILE, 'w', encoding='utf-8') as f:
        json.dump({"keys": data}, f, ensure_ascii=False, indent=2)

def update_excel_report():
    try:
        keys_data = load_keys()
        if not keys_data:
            return
        rows = []
        for k in keys_data:
            plan_info = PLANS.get(k["plan"], {})
            rows.append({
                "Ключ": k["key"],
                "Тариф": plan_info.get("name", k["plan"]),
                "Статус": "Активен" if k["status"] == "active" else "Неактивен",
                "Устройств": f"{len(k['active_devices'])}/{k['max_devices']}",
                "Создан": k["created_at"],
                "Активирован": k["activated_at"] or "-",
                "Действует до": k["expires_at"] or "-",
                "Последний вход": k["last_login"] or "-"
            })
        df = pd.DataFrame(rows)
        df.to_excel(REPORT_FILE, index=False)
    except:
        pass

def check_and_activate(key, device_id):
    try:
        keys = load_keys()
        clean = key.strip().upper()
        idx = next((i for i, k in enumerate(keys) if k["key"].upper() == clean), None)

        if idx is None:
            return {"success": False, "message": "Ключ не найден."}

        now = datetime.now()
        now_str = now.strftime("%d.%m.%Y %H:%M")
        key_data = keys[idx]
        max_devices = key_data["max_devices"]
        active_devices = key_data["active_devices"]

        if key_data["status"] == "active" and key_data["expires_at"]:
            try:
                exp_date = datetime.strptime(key_data["expires_at"], "%d.%m.%Y")
                if now > exp_date:
                    key_data["status"] = "expired"
                    save_keys(keys)
                    update_excel_report()
                    return {"success": False, "message": "Срок действия истек."}
            except:
                pass

        if key_data["status"] == "inactive":
            key_data["status"] = "active"
            key_data["activated_at"] = now_str
            key_data["expires_at"] = (now + timedelta(days=365)).strftime("%d.%m.%Y")
            key_data["last_login"] = now_str
            key_data["active_devices"] = [device_id]
            save_keys(keys)
            update_excel_report()
            return {"success": True, "message": f"Активировано! До {key_data['expires_at']}"}

        elif key_data["status"] == "active":
            if device_id in active_devices:
                key_data["last_login"] = now_str
                save_keys(keys)
                update_excel_report()
                return {"success": True, "message": "С возвращением!"}
            else:
                if len(active_devices) < max_devices:
                    active_devices.append(device_id)
                    key_data["last_login"] = now_str
                    save_keys(keys)
                    update_excel_report()
                    return {"success": True, "message": f"Добавлено! {len(active_devices)}/{max_devices}"}
                else:
                    return {"success": False, "message": f"Лимит исчерпан ({max_devices})"}

        return {"success": False, "message": "Неизвестный статус"}
    except Exception as e:
        return {"success": False, "message": f"Ошибка: {e}"}

def get_profile(key):
    try:
        keys = load_keys()
        clean = key.strip().upper()
        idx = next((i for i, k in enumerate(keys) if k["key"].upper() == clean), None)
        if idx is None:
            return {"success": False, "message": "Ключ не найден"}
        key_data = keys[idx]
        plan_info = PLANS.get(key_data["plan"], {})
        return {
            "success": True,
            "plan": plan_info.get("name", "Unknown"),
            "key": key_data["key"],
            "max_devices": key_data["max_devices"],
            "used_devices": len(key_data["active_devices"]),
            "available_devices": key_data["max_devices"] - len(key_data["active_devices"]),
            "expires_at": key_data.get("expires_at", ""),
            "activated_at": key_data.get("activated_at", ""),
            "last_login": key_data.get("last_login", "")
        }
    except Exception as e:
        return {"success": False, "message": f"Ошибка: {e}"}