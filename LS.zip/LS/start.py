import os
import subprocess
import sys

print("=" * 60)
print("  L1rtus Project - Запуск")
print("=" * 60)

# Проверка зависимостей
try:
    import flask
    import pandas
except ImportError:
    print("\n⚠️  Устанавливаю зависимости...")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])
    print("✅ Готово!")

# Запуск сервера
server_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'backend', 'server.py')
subprocess.run([sys.executable, server_path])